# -*- coding: UTF-8 -*-
#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      admin
#
# Created:     15.10.2013
# Copyright:   (c) admin 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

from pylab import *
import numpy as np
import random as rnd
import matplotlib as mpl
import matplotlib.pyplot as plt

def pca_nipals(X, *args):
    # calculation of number of components
    X_r = shape(X)[0]; X_c = shape(X)[1]
    P=[]; T=[]
    #
    if (len(args) > 0):
        pc = args[0]
    else:
        if (X_r < X_c ):
            pc = X_r
        else:
            pc = X_c
    # calculation of scores and loadings for each component
    P1 = np.matrix([]); T1 = np.matrix([]); #X = np.matrix(X)
    for k in range(1, pc+1):
        P1 = np.matrix(np.random.rand(X_c, 1))
        T1 = X * P1
        d0 = T1.conj().transpose() * T1
        P1 = ((T1.conj().transpose() * X)/d0).conj().transpose()
        P1 = P1/sqrt(P1.conj().transpose() * P1)
        #
        T1 = X * P1
        d = T1.conj().transpose() * T1
        #
        while (d - d0 > 0.0001):
            P1 = ((T1.conj().transpose() * X)/d0).conj().transpose()
            P1 = P1/sqrt(P1.conj().transpose() * P1)
            T1 = X * P1
            d0 = T1.conj().transpose() * T1
            #
            P1 = ((T1.conj().transpose() * X)/d0).conj().transpose()
            P1 = P1/sqrt(P1.conj().transpose() * P1)
            T1 = X * P1
            d = T1.conj().transpose() * T1
        X = X - T1 * P1.conj().transpose()
        P.append(P1.tolist()) #np.concatenate(P,P1)
        T.append(T1.tolist()) #np.concatenate(P,P1)
        TT = np.array(T)
        PP = np.array(P)
    return reshape(TT,[np.shape(TT)[0], np.shape(TT)[1]]), \
           reshape(PP,[np.shape(PP)[0], np.shape(PP)[1]]).conj().transpose()

def pcasvd_my(X):
    ''' pcasvd: calculates PCA components.
    The output matrices are T and P.
    T contains scores
    P contains loadings'''
    #
    U, D, V = np.linalg.svd( X, full_matrices=False )
    T = U * D
    P = V
    #
    return T, P

def classify_pca(vectors, pca_loadings, vec_centering, vec_scaling):
    # centering
    x_cent, ccc_in = centering_my(vectors, vec_centering)
    #
    # scaling
    x_scal, sss_in = scaling_my(x_cent, vec_scaling)
    #
    # classify
    pca_scores = np.matrix(x_scal)*(np.matrix(pca_loadings).transpose())
    return pca_scores

def csvread_my_toarr(path_file, delim='\t'):
    #
    readFile = open(path_file, mode="r")
    tmp = np.array([])
    #ind = 1
    for line in readFile: # iterate over file?s lines
        #print line
        tmp_arr = np.array([float(s) for s in line.split(delim)])
        tmp = np.concatenate((tmp,tmp_arr))
        #tmp.append(tmp_list))
    #
    readFile.close()
    return tmp.reshape((-1,len(tmp_arr)))

def csvread_my_tolist(path_file):
    #
    readFile = open(path_file, mode="r")
    tmp = []
    for line in readFile: # iterate over file?s lines
        #print line
        tmp.append([float(s) for s in line.split(',')])
    #
    readFile.close()
    return tmp

def csvwrite_my(path_file, itemlist):
    with open(path_file, 'w') as of:
        for item_1 in itemlist:
            of.write("\t".join([str(item_2) for item_2 in item_1]))
            of.write("\n")

def centering_my(in_X, *args):
    #
    if ( len(args) > 0 ):
        mean_X = args[0]
    else:
        mean_X = np.mean(in_X, 0) # mean value of columns
    if (len(shape(in_X)) > 1):
        m = size(in_X, 0)
    else:
        m = 1
    Xc = in_X - np.ones((m, 1))*mean_X
    #
    return Xc, mean_X

def scaling_my(in_Xs, *args):
    #
    if ( len(args) > 0 ):
        std_X = args[0]
    else:
        std_X = in_Xs.std(axis=0) # Standard deviation
    Xs = np.matrix( in_Xs ) * np.matrix( inv(diag(std_X)) )
    #
    return Xs, std_X

def for_cyrilic_plot():
    #поддержка кирилицы
    mpl.rcParams["text.usetex"] = False
    mpl.rcParams['font.family'] = 'sans-serif'
    #mpl.rcParams['font.serif']="Verdana, Arial"
    mpl.rcParams['font.sans-serif']="Tahoma, Arial"
    #mpl.rcParams['font.cursive']="Courier New, Arial"
    #mpl.rcParams['font.fantasy']="Comic Sans MS, Arial"
    mpl.rcParams['font.monospace']="Arial"

def stroi_scores(X,C):
    for_cyrilic_plot()
    #
    tmp = []
    i = 0
    while ( size(C) != size((C == -1).nonzero()) ):
        if (C[i] == -1):
            i = i + 1
        else:
            j = (C == C[i]).nonzero()
            i = i + 1
            tmp.append(j)
            C[j] = -1
        #
    #
    type_point = ['s','^','o','v','x'] # '8',(5,1)
    type_color = ['r','g','b','y','c','k']

    tmp_fontsize = 22
    tmp_fontweight = 'normal'
    ax = gca()
    #plt.hold(True)
    tmp_label = []
    for i in range(0,size(tmp,0)):
        #print tmp[i]
        tmp_point_color = [rnd.sample(type_point, 1)[0], rnd.sample(type_color, 1)[0]]
        print(tmp_point_color)
        plt.scatter(X[tmp[i],0], X[tmp[i],1], c=tmp_point_color[1], marker=tmp_point_color[0], s=200, edgecolor=tmp_point_color[1], linewidth= 3.0) #
        #plt.setp(hPlot) #, 'linewidth', 4.0 'markersize', 18.0, 'markeredgewidth', 4.0
        #plt.legend([u'Д'+str(i)], prop={"size":tmp_fontsize}, bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
        tmp_label.append(u'Д'+str(i+1))
    #

     #
    plt.legend(tmp_label,prop={"size":tmp_fontsize}, bbox_to_anchor=(1.01, 1), loc=2, borderaxespad=0.)

    xlabel(u'Главная компонента 1', fontsize=tmp_fontsize, fontweight=tmp_fontweight)
    ylabel(u'Главная компонента 2', fontsize=tmp_fontsize, fontweight=tmp_fontweight)

    for tick in ax.xaxis.get_major_ticks():
        tick.label1.set_fontsize(tmp_fontsize)
        tick.label1.set_fontweight(tmp_fontweight)
    for tick in ax.yaxis.get_major_ticks():
        tick.label1.set_fontsize(tmp_fontsize)
        tick.label1.set_fontweight(tmp_fontweight)

##    xticks( array([0, 500, 1000, 1500, 2000, 2500, 3000]), [u'$0$', u'$0,5$', u'$1,0$', u'$1,5$', u'$2,0$', u'$2,5$', u'$ГК1$'])
##    yticks( np.arange(0,1.2,0.2), convert_for_plot(np.arange(0,1,0.2)) )

    plt.show()

if __name__ == '__main__':
    tmp_data = np.array(csvread_my_toarr('data_Khitsenko.txt', ','))
    tmp_data_c, ccc = centering_my(tmp_data)
    tmp_data_s, sss = scaling_my(tmp_data_c)
    T, P = pca_nipals(tmp_data_s, 4)
    #T, P = pcasvd_my(np.array(tmp_data_s))
    csvwrite_my('data_Khitsenko_pca.txt', T) #np.matrix(np.array(T))
    #
    #for ind in range(0, len(T[:,0])):
    #    plt.text(T[ind,0]+0.2, T[ind,1]+0.2, str(ind+1), fontsize=22)
    # n - количество групп, m - число образцов в группе
    tmp_data_pca = np.array(csvread_my_toarr('data_Khitsenko_pca.txt', '\t'))
    n=2; m=10;
    id_classes = ( (np.arange(1,n+1).reshape((-1,1)) * np.ones((1,m))).reshape((1,-1)) )[0]
    stroi_scores(tmp_data_pca[0:2,:].conj().transpose(),id_classes)
    #
    #scores_classify = classify_pca(tmp_data[60:62], P, ccc, sss) #
    #
    #n=6; m=10; id_classes = (np.arange(1,n+1).reshape((-1,1)) * np.ones((1,m))).reshape((1,-1))
    # id_classes = np.array([1,1,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,2,2,2,3,3,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,5,5,5,5])
    #plt.text(np.asarray(scores_classify[0,0]) + 2, np.asarray(scores_classify[0,1])-0.85, u'Д7.1', fontsize=22)
    #plt.text(np.asarray(scores_classify[1,0]) + 2, np.asarray(scores_classify[1,1])-0.85, u'Д7.2', fontsize=22)
    #stroi_scores(np.vstack((T[:,0:2],np.asarray(scores_classify[:,0:2]))), np.hstack((id_classes[0],np.array([7,7])))) #np.hstack((id_classes[0],np.array([7,8])))




